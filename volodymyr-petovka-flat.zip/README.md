# Osobná stránka

Volodymyr Petovka, študent komerčnej logistiky na TUKE.
